# Halal Shots — Cloudflare Pages Admin Control Center

This is the Cloudflare-compatible continuation of the initial PHP prototype. Cloudflare Pages serves the preserved single-file public website from `public/index.html`; Pages Functions implement server-side API routes; Cloudflare D1 stores admin accounts, sessions, enquiries, CMS records, settings, and audit events.

## Current implementation scope

- Preserves the public site's single-file HTML/CSS/JS design and interactions.
- Replaces PHP-only API URLs with `/api/content` and `/api/enquiries` Pages Function routes.
- Booking enquiries are validated and persisted to D1; success is shown only after D1 confirms the write.
- Published services and testimonials are loaded from the public content API. Published portfolio projects replace the demo grid when configured.
- Branded admin login with PBKDF2-SHA-256 password verification, HttpOnly Secure session cookie, server-side session expiry, CSRF token, D1-backed login throttling, account activation checks, and audit events.
- Admin dashboard uses actual D1 metrics; booking enquiries can be searched, filtered, and updated with internal notes.
- Initial create/update CMS workflows for portfolio projects, services, and testimonials; basic brand/social settings; audit log viewer.
- Public content API returns published records only.

This is an initial functional foundation, **not the full production-ready system** from the master prompt. It does not yet include secure media upload/R2 processing, complete role/permission administration, email delivery, calendar/availability, full page editor, SEO tooling, analytics provider integration, automated backups, or comprehensive automated security/regression tests. It has not been deployed to a Cloudflare account or verified against a live D1 database.

## Why the architecture changed

Cloudflare Pages does not execute PHP files as a native runtime. The earlier PHP/SQLite prototype cannot run directly on Pages. This package uses:

- **Cloudflare Pages** — static public and admin HTML.
- **Pages Functions** — server-side API handlers under `functions/api/`.
- **D1** — managed SQLite-compatible database.
- **R2 (optional, future phase)** — media storage; do not store uploads in the static Pages deployment.

## 1. Create a Git repository

Upload this project to a GitHub repository. Do not commit `.dev.vars`, passwords, API secrets, or real customer data. The public website remains `public/index.html`.

## 2. Create a Cloudflare Pages project

In Cloudflare Dashboard:

1. Workers & Pages → Create → Pages → Connect to Git.
2. Select the repository.
3. Framework preset: **None**.
4. Build command: leave empty (or use no build command).
5. Build output directory: `public`.
6. Deploy to a staging `*.pages.dev` URL first.

`wrangler.toml` is included for local Wrangler and binding configuration. Replace the all-zero placeholder `database_id` with the real D1 database ID. If using dashboard bindings, bind the database as `DB` and keep its name `halal-shots-db`.

## 3. Create and migrate D1

Install Node.js 20+ and dependencies:

```bash
npm install
npx wrangler login
npx wrangler d1 create halal-shots-db
```

Copy the returned database ID into `wrangler.toml`, then apply the migration:

```bash
npm run db:migrate:remote
```

For local development, use `npm run db:migrate:local`. Do not use production customer data in the local database.

## 4. Provision the first administrator

There is no public sign-up route and no default password. Run:

```bash
npm run admin:provision
```

The script asks for an email and masked password, then prints a SQL `INSERT` statement containing only the PBKDF2 password hash. Run that SQL against the D1 database:

```bash
npx wrangler d1 execute halal-shots-db --remote --command "INSERT INTO administrators(email,display_name,password_hash,role,active) VALUES('admin@example.com','Admin','PASTE_GENERATED_HASH','super_admin',1);"
```

Use the generated SQL as a template and preserve SQL quoting. The password itself is not included in the generated SQL. Do not paste the hash into a public issue or commit it to source control. The account should be provisioned privately by the owner.

## 5. Configure a rate-limit secret

Generate a random value and add `RATE_LIMIT_SALT` under Pages → Settings → Variables and Secrets. Keep it private. Add the same variable in `.dev.vars` for local development. The public booking endpoint has a basic per-IP hash limit stored with enquiries; for production, add Cloudflare WAF/rate limiting rules as well.

## 6. Local development

```bash
cp .dev.vars.example .dev.vars
npm install
npm run db:migrate:local
npm run dev
```

Run the dev server with a D1 local binding. If Wrangler reports the database binding is missing, verify the `wrangler.toml` database configuration and replace the placeholder ID. Provision a local admin in the local D1 database before attempting login.

## 7. URLs

- Public website: `/`
- Admin: `/admin/` or `/admin`
- Admin login: `/admin/login` or `/admin/login.html`
- Public content API: `/api/content`
- Public booking API: `/api/enquiries`
- Admin session: `/api/admin/me`
- Admin login/logout: `/api/admin/login`, `/api/admin/logout`
- Admin dashboard: `/api/admin/dashboard`
- Admin bookings: `/api/admin/bookings`
- Admin content/settings: `/api/admin/content`
- Admin audit logs: `/api/admin/audit`

## 8. Production checklist

- Bind D1 under the name `DB` and run remote migrations.
- Configure a custom domain and enforce HTTPS.
- Set `RATE_LIMIT_SALT` as a secret.
- Provision at least one owner-controlled super administrator.
- Test login throttling, logout/session invalidation, CSRF failures, public enquiry validation, D1 persistence, draft privacy, and role checks.
- Add Cloudflare WAF/rate limiting rules for `/api/enquiries` and `/api/admin/login`.
- Configure Cloudflare backups/exports for D1 and test a restore procedure.
- Add R2 with private server-side bindings before implementing uploads.
- Configure transactional email before promising email notifications.
- Replace demonstration photography and sample testimonial content with approved assets/reviews. The site intentionally contains no invented social links.
- Test at the target responsive widths and check browser console errors.

## Known gaps / next phases

1. Add administrator role management, invitation/reset flows, stronger authorization matrix, and durable per-account throttling.
2. Add booking status history, assignment, calendar/availability rules, CSV export with formula-injection defenses, and client directory.
3. Complete portfolio/service/testimonial editing, including delete/archive/restore and category management. Public portfolio rendering is currently synchronized only when at least one published CMS project exists.
4. Add R2-backed media uploads with MIME/content validation, safe image processing, reference tracking, and private asset rules.
5. Add page-content editor, SEO metadata, sitemap/robots support, and version history.
6. Add verified email integration, queued notifications/retries, analytics, and health checks.
7. Add automated unit/integration tests and run live Cloudflare Pages + D1 security and responsive regression testing.

Never mark these gaps complete until implemented and tested.
