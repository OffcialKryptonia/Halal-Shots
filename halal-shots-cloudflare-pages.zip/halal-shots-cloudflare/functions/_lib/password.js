const ITERATIONS = 310000;
const enc = new TextEncoder();
function b64url(bytes) { return btoa(String.fromCharCode(...new Uint8Array(bytes))).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,''); }
function fromB64url(value) { const padded=value.replaceAll('-','+').replaceAll('_','/')+'='.repeat((4-value.length%4)%4); return Uint8Array.from(atob(padded),c=>c.charCodeAt(0)); }
export async function verifyPassword(password, encoded) {
  try {
    const [scheme, rounds, salt, expected] = encoded.split('$');
    if (scheme !== 'pbkdf2-sha256' || Number(rounds) < 200000 || !salt || !expected) return false;
    const key = await crypto.subtle.importKey('raw',enc.encode(password),'PBKDF2',false,['deriveBits']);
    const actual = new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:fromB64url(salt),iterations:Number(rounds)},key,256));
    const exp = fromB64url(expected); if (actual.length !== exp.length) return false;
    let diff=0; for(let i=0;i<actual.length;i++) diff |= actual[i]^exp[i]; return diff===0;
  } catch { return false; }
}
