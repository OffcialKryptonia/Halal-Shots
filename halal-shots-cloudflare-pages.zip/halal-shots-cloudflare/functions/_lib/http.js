export function json(data, status = 200, headers = {}) {
  return new Response(JSON.stringify(data), { status, headers: {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
    'referrer-policy': 'strict-origin-when-cross-origin',
    ...headers
  }});
}
export function error(message, status = 400) { return json({ ok: false, error: message }, status); }
export async function readJson(request, maxBytes = 16000) {
  const length = Number(request.headers.get('content-length') || 0);
  if (length > maxBytes) throw new Error('Request too large.');
  const raw = await request.text();
  if (raw.length > maxBytes) throw new Error('Request too large.');
  try { return JSON.parse(raw); } catch { throw new Error('Invalid JSON.'); }
}
export function safeText(value, max = 1000) { return String(value ?? '').trim().slice(0, max); }
export function cookieValue(request, name) {
  const cookies = request.headers.get('cookie') || '';
  const found = cookies.split(';').map(v => v.trim()).find(v => v.startsWith(`${name}=`));
  return found ? decodeURIComponent(found.slice(name.length + 1)) : '';
}
export async function sha256(value) {
  const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value));
  return [...new Uint8Array(bytes)].map(b => b.toString(16).padStart(2, '0')).join('');
}
export function securityHeaders(response) {
  const h = new Headers(response.headers);
  h.set('x-content-type-options','nosniff');
  h.set('referrer-policy','strict-origin-when-cross-origin');
  h.set('x-frame-options','DENY');
  h.set('permissions-policy','camera=(), microphone=(), geolocation=()');
  return new Response(response.body,{status:response.status,statusText:response.statusText,headers:h});
}
