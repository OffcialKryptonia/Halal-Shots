import { cookieValue, sha256, json } from './http.js';
export async function currentAdmin(request, env) {
  const token = cookieValue(request, 'hs_admin');
  if (!token || token.length < 40) return null;
  const tokenHash = await sha256(token);
  const row = await env.DB.prepare(`SELECT s.id AS session_id,s.csrf_token,s.expires_at,a.id,a.email,a.display_name,a.role,a.active
    FROM admin_sessions s JOIN administrators a ON a.id=s.administrator_id
    WHERE s.token_hash=? AND s.expires_at > ? AND a.active=1`).bind(tokenHash,new Date().toISOString()).first();
  if (!row) return null;
  return { id: row.id, email: row.email, display_name: row.display_name, role: row.role, session_id: row.session_id, csrf_token: row.csrf_token };
}
export async function requireAdmin(request, env) {
  const admin = await currentAdmin(request, env);
  if (!admin) return { response: json({ok:false,error:'Authentication required.'},401), admin:null };
  if (request.method !== 'GET' && request.method !== 'HEAD') {
    const supplied = request.headers.get('x-csrf-token') || '';
    if (!supplied || supplied !== admin.csrf_token) return { response: json({ok:false,error:'Security token invalid. Refresh and try again.'},403), admin:null };
  }
  return {admin,response:null};
}
export function canManageContent(admin) { return ['super_admin','admin','photographer_editor'].includes(admin?.role); }
export function canManageSettings(admin) { return admin?.role === 'super_admin'; }
