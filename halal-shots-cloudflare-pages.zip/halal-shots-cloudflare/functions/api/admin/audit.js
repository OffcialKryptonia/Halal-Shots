import { json } from '../../_lib/http.js';
import { requireAdmin } from '../../_lib/auth.js';
export async function onRequestGet({request,env}) {
 const check=await requireAdmin(request,env);if(check.response)return check.response;
 if(check.admin.role!=='super_admin')return json({ok:false,error:'Only a super administrator can view audit logs.'},403);
 const rows=await env.DB.prepare('SELECT l.id,l.action,l.entity,l.entity_id,l.created_at,a.email AS administrator_email FROM audit_logs l LEFT JOIN administrators a ON a.id=l.administrator_id ORDER BY l.created_at DESC LIMIT 100').all();return json({ok:true,items:rows.results||[]});
}
