import { json, readJson, safeText, sha256 } from '../../_lib/http.js';
import { verifyPassword } from '../../_lib/password.js';
export async function onRequestPost({request,env}) {
  let body; try { body=await readJson(request,5000); } catch(e) { return json({ok:false,error:e.message},400); }
  const email=safeText(body.email,254).toLowerCase(); const password=String(body.password||'');
  const ip=request.headers.get('cf-connecting-ip')||'unknown'; const ipHash=await sha256(`${ip}:${env.RATE_LIMIT_SALT||'halalshots-rate-v1'}`);
  const attempts=await env.DB.prepare("SELECT COUNT(*) AS n FROM login_attempts WHERE ip_hash=? AND julianday(attempted_at) >= julianday('now','-15 minutes')").bind(ipHash).first();
  if ((attempts?.n||0)>=10) return json({ok:false,error:'Too many attempts. Please wait and try again.'},429);
  const user=await env.DB.prepare('SELECT id,email,display_name,password_hash,role,active FROM administrators WHERE email=? COLLATE NOCASE').bind(email).first();
  const valid=!!user && user.active===1 && password.length<=1024 && await verifyPassword(password,user.password_hash);
  await env.DB.prepare('INSERT INTO login_attempts(ip_hash,successful) VALUES(?,?)').bind(ipHash,valid?1:0).run();
  await env.DB.prepare("DELETE FROM login_attempts WHERE julianday(attempted_at) < julianday('now','-2 days')").run();
  if (!valid) return json({ok:false,error:'Unable to sign in with those credentials.'},401);
  const token=Array.from(crypto.getRandomValues(new Uint8Array(32)),b=>b.toString(16).padStart(2,'0')).join('');
  const tokenHash=await sha256(token); const csrf=Array.from(crypto.getRandomValues(new Uint8Array(24)),b=>b.toString(16).padStart(2,'0')).join('');
  const expires=new Date(Date.now()+8*60*60*1000).toISOString();
  await env.DB.prepare('INSERT INTO admin_sessions(administrator_id,token_hash,csrf_token,expires_at) VALUES(?,?,?,?)').bind(user.id,tokenHash,csrf,expires).run();
  await env.DB.prepare('UPDATE administrators SET last_login=? WHERE id=?').bind(new Date().toISOString(),user.id).run();
  await env.DB.prepare('INSERT INTO audit_logs(administrator_id,action,entity,entity_id) VALUES(?,?,?,?)').bind(user.id,'login','administrator',String(user.id)).run();
  return json({ok:true,administrator:{email:user.email,display_name:user.display_name,role:user.role},csrfToken:csrf},200,{'set-cookie':`hs_admin=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=28800`});
}
export async function onRequestGet() { return json({ok:false,error:'Method not allowed.'},405); }
