import { json, cookieValue, sha256 } from '../../_lib/http.js';
import { requireAdmin } from '../../_lib/auth.js';
export async function onRequestPost(ctx) {
 const {request,env}=ctx; const check=await requireAdmin(request,env); if(check.response)return check.response;
 const token=cookieValue(request,'hs_admin');
 if(token) await env.DB.prepare('DELETE FROM admin_sessions WHERE token_hash=?').bind(await sha256(token)).run();
 await env.DB.prepare('INSERT INTO audit_logs(administrator_id,action,entity,entity_id) VALUES(?,?,?,?)').bind(check.admin.id,'logout','administrator',String(check.admin.id)).run();
 return json({ok:true},200,{'set-cookie':'hs_admin=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0'});
}
