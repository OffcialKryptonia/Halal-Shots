import { json } from '../../_lib/http.js';
import { requireAdmin } from '../../_lib/auth.js';
export async function onRequestGet(ctx) {
 const {request,env}=ctx; const check=await requireAdmin(request,env); if(check.response)return check.response;
 const queries=await Promise.all([
  env.DB.prepare('SELECT COUNT(*) n FROM booking_enquiries').first(),
  env.DB.prepare("SELECT COUNT(*) n FROM booking_enquiries WHERE status='New'").first(),
  env.DB.prepare("SELECT COUNT(*) n FROM booking_enquiries WHERE status='Confirmed'").first(),
  env.DB.prepare("SELECT COUNT(*) n FROM portfolio_projects WHERE status='published'").first(),
  env.DB.prepare("SELECT COUNT(*) n FROM portfolio_projects WHERE status='draft'").first(),
  env.DB.prepare("SELECT COUNT(*) n FROM services WHERE status='published'").first(),
  env.DB.prepare('SELECT id,reference,full_name,email,service,preferred_date,status,created_at FROM booking_enquiries ORDER BY created_at DESC LIMIT 8').all()
 ]);
 return json({ok:true,metrics:{enquiries:queries[0]?.n||0,newEnquiries:queries[1]?.n||0,confirmed:queries[2]?.n||0,publishedPortfolio:queries[3]?.n||0,draftPortfolio:queries[4]?.n||0,publishedServices:queries[5]?.n||0},recentEnquiries:queries[6]?.results||[]});
}
