import { json } from '../../_lib/http.js';
import { currentAdmin } from '../../_lib/auth.js';
export async function onRequestGet({request,env}) {
 const admin=await currentAdmin(request,env);
 if(!admin) return json({ok:false,error:'Authentication required.'},401,{'set-cookie':'hs_admin=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0'});
 await env.DB.prepare('UPDATE admin_sessions SET last_seen_at=? WHERE id=?').bind(new Date().toISOString(),admin.session_id).run();
 return json({ok:true,administrator:{id:admin.id,email:admin.email,display_name:admin.display_name,role:admin.role},csrfToken:admin.csrf_token});
}
