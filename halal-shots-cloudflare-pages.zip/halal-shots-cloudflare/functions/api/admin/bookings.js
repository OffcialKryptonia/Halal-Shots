import { json, readJson, safeText } from '../../_lib/http.js';
import { requireAdmin } from '../../_lib/auth.js';
const STATUSES=['New','Contacted','Awaiting Client Response','Quotation Sent','Confirmed','In Progress','Completed','Cancelled','Archived'];
export async function onRequestGet({request,env}) {
 const check=await requireAdmin(request,env); if(check.response)return check.response;
 const url=new URL(request.url); const q=safeText(url.searchParams.get('q'),120); const status=safeText(url.searchParams.get('status'),40); const page=Math.max(1,Number(url.searchParams.get('page')||1)); const limit=25; const offset=(page-1)*limit;
 let sql='SELECT id,reference,full_name,email,phone,service,preferred_date,location,details,status,notes,created_at,updated_at FROM booking_enquiries WHERE 1=1';const args=[];
 if(q){sql+=' AND (full_name LIKE ? OR email LIKE ? OR phone LIKE ? OR reference LIKE ?)';for(let i=0;i<4;i++)args.push(`%${q}%`);}
 if(STATUSES.includes(status)){sql+=' AND status=?';args.push(status);}
 const count=await env.DB.prepare(sql.replace('SELECT id,reference,full_name,email,phone,service,preferred_date,location,details,status,notes,created_at,updated_at','SELECT COUNT(*) AS n')).bind(...args).first();
 sql+=' ORDER BY created_at DESC LIMIT ? OFFSET ?'; args.push(limit,offset);
 const rows=await env.DB.prepare(sql).bind(...args).all();return json({ok:true,items:rows.results||[],page,total:count?.n||0,limit});
}
export async function onRequestPatch({request,env}) {
 const check=await requireAdmin(request,env);if(check.response)return check.response;let body;try{body=await readJson(request,8000)}catch(e){return json({ok:false,error:e.message},400)}
 const id=Number(body.id);const status=safeText(body.status,40);const notes=safeText(body.notes,3000);
 if(!Number.isInteger(id)||id<1||!STATUSES.includes(status))return json({ok:false,error:'Invalid booking update.'},422);
 const before=await env.DB.prepare('SELECT id,status FROM booking_enquiries WHERE id=?').bind(id).first();if(!before)return json({ok:false,error:'Enquiry not found.'},404);
 await env.DB.prepare('UPDATE booking_enquiries SET status=?,notes=?,updated_at=? WHERE id=?').bind(status,notes,new Date().toISOString(),id).run();
 await env.DB.prepare('INSERT INTO audit_logs(administrator_id,action,entity,entity_id,metadata) VALUES(?,?,?,?,?)').bind(check.admin.id,'booking.update','booking_enquiry',String(id),JSON.stringify({from:before.status,to:status})).run();
 return json({ok:true});
}
