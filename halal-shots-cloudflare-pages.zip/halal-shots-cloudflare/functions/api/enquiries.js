import { json, readJson, safeText, sha256 } from '../_lib/http.js';
export async function onRequestPost({request,env}) {
 let input;try{input=await readJson(request,16000)}catch(e){return json({ok:false,error:e.message},400)}
 if(safeText(input.website,200)) return json({ok:true},202);
 const ip=request.headers.get('cf-connecting-ip')||'unknown';const ipHash=await sha256(`${ip}:${env.RATE_LIMIT_SALT||'halalshots-public-v1'}`);
 const attempts=await env.DB.prepare("SELECT COUNT(*) AS n FROM booking_enquiries WHERE ip_hash=? AND julianday(created_at) >= julianday('now','-1 hour')").bind(ipHash).first().catch(()=>({n:0}));
 // The migration stores only a hash of the submitting IP for abuse throttling.
 if((attempts?.n||0)>=8)return json({ok:false,error:'Too many enquiries were submitted. Please wait and try again.'},429);
 const idempotencyKey=safeText(request.headers.get('idempotency-key'),80);
 if(idempotencyKey && !/^[a-zA-Z0-9_-]{16,80}$/.test(idempotencyKey))return json({ok:false,error:'Invalid submission token.'},422);
 if(idempotencyKey){const previous=await env.DB.prepare('SELECT reference FROM booking_enquiries WHERE idempotency_key=?').bind(idempotencyKey).first();if(previous)return json({ok:true,reference:previous.reference,replayed:true},200);}
 const name=safeText(input.fullName,121),email=safeText(input.email,255).toLowerCase(),phone=safeText(input.phone,41),service=safeText(input.service,141),date=safeText(input.date,11),location=safeText(input.location,251),details=safeText(input.details,4001);
 if(!name||name.length>120||!/^\S+@\S+\.\S+$/.test(email)||email.length>254||phone.length>40||location.length>250||details.length>4000)return json({ok:false,error:'Please check your enquiry details and try again.'},422);
 if(date&&(!/^\d{4}-\d{2}-\d{2}$/.test(date)||Number.isNaN(Date.parse(`${date}T00:00:00Z`))))return json({ok:false,error:'Please choose a valid preferred date.'},422);
 const found=await env.DB.prepare("SELECT id FROM services WHERE title=? AND status='published'").bind(service).first();
 if(!found)return json({ok:false,error:'Please select one of the currently available services.'},422);
 const reference=`HS-${new Date().toISOString().slice(2,10).replaceAll('-','')}-${crypto.randomUUID().slice(0,8).toUpperCase()}`;
 try{await env.DB.prepare('INSERT INTO booking_enquiries(reference,idempotency_key,full_name,email,phone,service,preferred_date,location,details,ip_hash) VALUES(?,?,?,?,?,?,?,?,?,?)').bind(reference,idempotencyKey||null,name,email,phone,service,date,location,details,ipHash).run();}
 catch(e){console.error('Enquiry persistence failed',e?.message||'unknown');return json({ok:false,error:'We could not save your enquiry just now. Please try again shortly.'},503)}
 return json({ok:true,reference},201);
}
