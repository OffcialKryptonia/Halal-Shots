import { json } from '../_lib/http.js';
export async function onRequestGet({env}) {
 try {
  const [settings,services,testimonials,portfolio]=await Promise.all([
   env.DB.prepare('SELECT key,value FROM site_settings').all(),
   env.DB.prepare("SELECT id,title,description,sort_order FROM services WHERE status='published' ORDER BY sort_order,id").all(),
   env.DB.prepare("SELECT id,quote,client_name,session_type,sort_order FROM testimonials WHERE status='published' ORDER BY sort_order,id").all(),
   env.DB.prepare("SELECT id,title,slug,category,description,image_url,alt_text,featured,sort_order FROM portfolio_projects WHERE status='published' ORDER BY featured DESC,sort_order,id").all()
  ]);
  return json({ok:true,settings:Object.fromEntries((settings.results||[]).map(r=>[r.key,r.value])),services:services.results||[],testimonials:testimonials.results||[],portfolio:portfolio.results||[]},200,{'cache-control':'public, max-age=60, s-maxage=60'});
 } catch(e) { console.error('Public content unavailable',e?.message||'unknown'); return json({ok:false,error:'Content temporarily unavailable.'},503); }
}
