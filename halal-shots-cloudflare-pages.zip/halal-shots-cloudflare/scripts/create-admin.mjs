#!/usr/bin/env node
import { pbkdf2Sync, randomBytes } from 'node:crypto';
import { createInterface } from 'node:readline';
const rl=createInterface({input:process.stdin,output:process.stdout});
const ask=q=>new Promise(resolve=>rl.question(q,resolve));
function askSecret(prompt){return new Promise(resolve=>{const stdin=process.stdin;let value='';process.stdout.write(prompt);if(!stdin.isTTY){rl.question('',answer=>resolve(answer));return;}stdin.setRawMode(true);stdin.resume();const onData=buffer=>{for(const ch of buffer.toString('utf8')){if(ch==='\u0003'){process.stdout.write('\n');process.exit(130)}if(ch==='\r'||ch==='\n'){stdin.removeListener('data',onData);stdin.setRawMode(false);stdin.pause();process.stdout.write('\n');resolve(value);return;}if(ch==='\u007f'||ch==='\b'){value=value.slice(0,-1);process.stdout.write('\b \b')}else if(ch>=' '){value+=ch;process.stdout.write('*')}}};stdin.on('data',onData);});}
function sqlString(value){return "'"+String(value).replaceAll("'","''")+"'"}
try{
 const email=(await ask('Administrator email: ')).trim().toLowerCase();
 rl.close();
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw Error('Enter a valid email address.');
 const password=await askSecret('Choose a unique password (minimum 14 characters): ');
 if(password.length<14)throw Error('Password must be at least 14 characters.');
 const confirm=await askSecret('Confirm password: ');if(password!==confirm)throw Error('Passwords do not match.');
 const rounds=310000,salt=randomBytes(16),hash=pbkdf2Sync(password,salt,rounds,32,'sha256');
 const enc=b=>b.toString('base64url');const encoded=`pbkdf2-sha256$${rounds}$${enc(salt)}$${enc(hash)}`;
 const displayName=email.split('@')[0].replace(/[._-]+/g,' ').replace(/\b\w/g,c=>c.toUpperCase());
 const sql=`INSERT INTO administrators(email,display_name,password_hash,role,active) VALUES(${sqlString(email)},${sqlString(displayName)},${sqlString(encoded)},'super_admin',1);\n`;
 process.stdout.write('\nRun the SQL below against your Cloudflare D1 database only after applying migrations. The password itself is not written to the SQL.\n\n'+sql);
} catch(e){console.error('\nError: '+e.message);process.exitCode=1;}finally{rl.close();}
