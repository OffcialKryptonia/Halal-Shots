# Acceptance checklist — not yet executed against Cloudflare

## Local / staging setup
- [ ] Pages Functions route resolution verified on `wrangler pages dev`.
- [ ] D1 binding `DB` resolves and migration `0001_initial.sql` applies cleanly.
- [ ] First administrator provisioned privately; no default credentials exist.
- [ ] Admin login, session cookie, CSRF rejection, logout and expiry tested.

## Enquiries
- [ ] Valid enquiry is persisted to D1 and returns a unique reference.
- [ ] Invalid email, overlong fields, unknown service and invalid date are rejected.
- [ ] D1 outage returns a failure and the public form does not claim success.
- [ ] Per-IP throttle and Cloudflare WAF/rate limits verified.
- [ ] Private enquiry API cannot be accessed without a valid admin session.

## CMS / public sync
- [ ] Published portfolio item appears in the public grid and filters/lightbox still work.
- [ ] Draft and archived projects do not appear publicly.
- [ ] Published service options update the booking selector.
- [ ] Published testimonials replace clearly identified sample content.
- [ ] Settings/social links accept only approved, verified destinations.

## Regression / security
- [ ] Test 360, 390, 640, 768, 1024, 1440 and 1920 px viewport widths.
- [ ] Verify intro loader, hero reveal, navigation overlay, booking modal and focus restoration.
- [ ] Verify keyboard lightbox controls and reduced-motion preferences.
- [ ] Test stored/reflected XSS payloads, SQL injection strings, CSRF, stale sessions, inactive accounts, brute-force throttling, draft leakage and direct admin API access.
- [ ] Verify no horizontal overflow or critical browser-console errors.
- [ ] Configure and test D1 backup/export and recovery before production.
