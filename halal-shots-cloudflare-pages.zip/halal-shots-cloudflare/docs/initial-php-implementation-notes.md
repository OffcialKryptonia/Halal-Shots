# Halal Shots — Admin Control Center (initial implementation)

## Inspected baseline
The source public site is `index.baseline.html` (unchanged). The working copy is `public/index.html` and retains the single-file HTML/CSS/JS presentation. Its features include cinematic hero canvas, Lenis via importmap, portfolio filtering and lightbox, services, testimonial carousel, booking modal and mobile navigation. The original form only simulated success; the working copy submits to a real PHP API. The original imagery and testimonials are illustrative, not verified Halal Shots assets/reviews.

## Runtime and setup
This is an **initial implementation**, not a completed production deployment. PHP 8.2+ with PDO SQLite, mbstring, OpenSSL and a writable private storage directory is needed. No live hosting configuration, production database or email credentials were supplied. This workspace does not have a PHP executable; PHP execution and browser integration tests have **not** been run.

1. Point your web server document root to `public/` (never to the repository root).
2. Keep `storage/`, `app/`, `bin/` and the baseline outside the public web root. Ensure `storage/` is writable only by the server user and backup operator.
3. Set `DB_DSN` to an absolute SQLite database path outside the public web root. Configure `APP_ENV=production` only on HTTPS. The sample `.env.example` is documentation: environment variables must actually be set in the host, not assumed to auto-load.
4. Run `php bin/install.php` from the command line to initialize the schema.
5. Provision the first administrator privately: `ADMIN_EMAIL='you@example.com' ADMIN_PASSWORD='use-a-long-unique-secret' php bin/install.php` (never put real credentials in code, screenshots or shell history). Remove these variables after provisioning. Passwords are Argon2id hashed.
6. Visit `/admin/index.php` and log in. The booking endpoint is `/api/enquiries.php`, public content endpoint `/api/content.php`.
7. Configure web server URL rewrites for friendly `/admin` if needed; `/admin/index.php` works without rewrites.

## Implemented
- Private administrator login, secure-cookie settings, session idle timeout, CSRF checks, audit events, account deactivation enforcement, Argon2id hashing and prepared SQL.
- Database schema for administrators, enquiries, portfolio, services, testimonials, settings and audit logs.
- Public booking submission with validation, persisted reference, coarse rate limiting, and real failure feedback. No fake success on backend failure.
- Dashboard with real database counts; booking list and status/notes editing; portfolio, service and testimonial create/update/publication states; restricted basic settings and audit list.
- Public CMS endpoint exposing published content only. Working frontend consumes configured hero copy, social links, published services for the booking selector, and published testimonials; other static sections remain unchanged.

## Not yet implemented / not production-ready
- The portfolio grid is **not yet dynamically synchronized** (current lightbox binds initial DOM nodes). Dynamic CMS portfolio rendering and filter rebinding remain essential.
- Full admin roles and permissions, invitations, password recovery, login rate limiting, pagination, robust edit/delete, calendar, client directory, media upload/storage, page editor, SEO, analytics, email, integration health checks, booking status history, versioning, and backup automation are not yet built.
- SQLite-specific install SQL and `INSERT OR IGNORE`/`REPLACE` are **not MySQL compatible**. Adapt schema and queries before deploying to MySQL/cPanel.
- Server-side rate limiting uses local temp files and is not robust for distributed hosting. Add reverse-proxy/WAF limits and durable login throttling.
- Login has a fixed delay but lacks durable rate limiting. Do not deploy publicly until that is addressed.
- Security, PHP lint, real browser and end-to-end tests have not been run. Admin forms need validation hardening and permission checks before public deployment.
- Booking submission does not send email yet. Enquiries persist only if a configured backend is reachable.

## Next implementation sequence
1. Run PHP syntax checks and runtime tests in a PHP-capable environment, resolve any issues.
2. Complete hardened auth, roles, rate limiting and admin authorization.
3. Make portfolio/services/testimonials fully synchronized with the existing UI, including event handlers and lightbox.
4. Implement secure media storage, complete CMS, booking workflows and email integration.
5. Deploy to staging with HTTPS, perform security and responsive regression tests, and configure backups before production.
